# Sample images

Optional: add a small number of example water-sample microscope images here, only if you are allowed to publish them. Do not upload the complete dataset without checking its licence and size.
