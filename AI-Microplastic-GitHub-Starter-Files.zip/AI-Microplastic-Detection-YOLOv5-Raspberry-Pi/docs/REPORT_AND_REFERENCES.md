# Project report and references

Place the approved project report PDF in this `docs/` folder. Then update the link in the main `README.md` using the actual PDF filename.

Before publishing, add and verify:

- The full Kaggle dataset title and URL (the report describes a 577-image dataset).
- The exact YOLOv5 repository/version or commit used.
- All papers, articles, software and datasets cited in the report.
- The dataset and model licences and any redistribution restrictions.

Do not invent missing bibliographic details. Copy references from the approved report and verify them.
