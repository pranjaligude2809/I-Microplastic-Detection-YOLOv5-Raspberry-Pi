# Trained model weights

The trained YOLOv5 checkpoint is not included in this starter package.

If your project has a compatible checkpoint, place it here as `best.pt` for the example command in the main README. The repository `.gitignore` intentionally excludes `.pt` files because model weights can be large. For large files, use Git LFS or link to a permitted, trusted download location. Never upload a model unless you have the right to share it.
