"""Run a local YOLOv5 custom checkpoint on a camera, image or video.

Example (USB microscope camera):
    python src/detect.py --source 0 --weights weights/best.pt --view

Example (one image):
    python src/detect.py --source images/sample.jpg --weights weights/best.pt --view

This is a starter integration example, not a substitute for the exact inference
code/configuration used in the original project. It expects a compatible
YOLOv5 custom checkpoint and a working PyTorch/YOLOv5 environment.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
from typing import Union

import cv2


def parse_source(value: str) -> Union[int, str]:
    return int(value) if value.isdecimal() else value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="YOLOv5 microplastic detection demo")
    parser.add_argument("--source", default="0", help="Camera index, image path or video path")
    parser.add_argument("--weights", type=Path, default=Path("weights/best.pt"), help="Trained YOLOv5 .pt checkpoint")
    parser.add_argument("--img-size", type=int, default=640, help="Inference image size")
    parser.add_argument("--conf", type=float, default=0.25, help="Confidence threshold (0 to 1)")
    parser.add_argument("--view", action="store_true", help="Show the annotated frames in a window")
    parser.add_argument("--save-video", type=Path, default=None, help="Optional path for annotated video output")
    return parser.parse_args()


def load_model(weights: Path, image_size: int, confidence: float):
    if not weights.is_file():
        raise FileNotFoundError(
            f"Model weights not found: {weights}. Add your trained YOLOv5 checkpoint "
            "(for example best.pt) at this path, or pass --weights with its location."
        )

    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("PyTorch is not installed. Install a build compatible with your device.") from exc

    try:
        # Requires network access on first use unless the YOLOv5 Hub repository is cached locally.
        model = torch.hub.load(
            "ultralytics/yolov5", "custom", path=str(weights), force_reload=False
        )
    except Exception as exc:  # Preserve the original exception in the chained traceback.
        raise RuntimeError(
            "Could not load the YOLOv5 model. Check PyTorch, YOLOv5 dependencies, "
            "internet/cache availability and checkpoint compatibility."
        ) from exc

    model.conf = confidence
    model.imgsz = image_size
    return model


def main() -> int:
    args = parse_args()
    if not 0.0 <= args.conf <= 1.0:
        print("Error: --conf must be between 0 and 1.", file=sys.stderr)
        return 2
    if args.img_size <= 0:
        print("Error: --img-size must be greater than zero.", file=sys.stderr)
        return 2

    try:
        model = load_model(args.weights, args.img_size, args.conf)
    except (FileNotFoundError, RuntimeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    source = parse_source(args.source)
    capture = cv2.VideoCapture(source)
    if not capture.isOpened():
        print(f"Error: could not open source {args.source!r}.", file=sys.stderr)
        return 1

    writer = None
    frame_count = 0
    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                break

            predictions = model(frame, size=args.img_size)
            annotated = predictions.render()[0]
            frame_count += 1

            if args.view:
                cv2.imshow("YOLOv5 microplastic detection", annotated)
                if (cv2.waitKey(1) & 0xFF) in (ord("q"), ord("Q")):
                    break

            if args.save_video is not None:
                args.save_video.parent.mkdir(parents=True, exist_ok=True)
                if writer is None:
                    height, width = annotated.shape[:2]
                    fps = capture.get(cv2.CAP_PROP_FPS)
                    if not fps or fps <= 0:
                        fps = 20.0
                    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                    writer = cv2.VideoWriter(str(args.save_video), fourcc, fps, (width, height))
                    if not writer.isOpened():
                        raise RuntimeError(f"Could not create output video: {args.save_video}")
                writer.write(annotated)

        print(f"Finished. Processed {frame_count} frame(s).")
        if args.save_video is not None:
            print(f"Annotated video: {args.save_video}")
    except KeyboardInterrupt:
        print("Stopped by user.")
    except Exception as exc:
        print(f"Error during detection: {exc}", file=sys.stderr)
        return 1
    finally:
        capture.release()
        if writer is not None:
            writer.release()
        if args.view:
            cv2.destroyAllWindows()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
