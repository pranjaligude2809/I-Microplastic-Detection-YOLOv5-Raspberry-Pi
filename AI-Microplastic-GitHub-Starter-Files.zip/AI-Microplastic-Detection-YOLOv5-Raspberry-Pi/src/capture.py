"""Capture still images from a USB microscope/webcam using OpenCV.

Press S to save an image and Q to quit. Run from the repository root:
    python src/capture.py --camera 0 --output data/samples
"""
from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import sys

import cv2


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Capture microscope images")
    parser.add_argument("--camera", type=int, default=0, help="Camera device index (usually 0)")
    parser.add_argument(
        "--output", type=Path, default=Path("data/samples"),
        help="Folder in which captured images will be saved",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    camera = cv2.VideoCapture(args.camera)
    if not camera.isOpened():
        print(
            f"Error: could not open camera index {args.camera}. "
            "Check the USB connection and try another --camera index.",
            file=sys.stderr,
        )
        return 1

    print("Camera ready. Press S to save a frame; press Q to quit.")
    try:
        while True:
            ok, frame = camera.read()
            if not ok:
                print("Warning: camera frame could not be read.", file=sys.stderr)
                break

            cv2.imshow("Microscope image capture", frame)
            key = cv2.waitKey(1) & 0xFF

            if key in (ord("s"), ord("S")):
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
                image_path = args.output / f"microscope_{timestamp}.jpg"
                if cv2.imwrite(str(image_path), frame):
                    print(f"Saved: {image_path}")
                else:
                    print(f"Error: could not save {image_path}", file=sys.stderr)
            elif key in (ord("q"), ord("Q")):
                break
    finally:
        camera.release()
        cv2.destroyAllWindows()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
