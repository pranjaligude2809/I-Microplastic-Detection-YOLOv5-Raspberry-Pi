# AI-Based Real-Time Microplastic Detection System Using YOLOv5 and Raspberry Pi

An academic project exploring image-based detection of microplastic-like particles in water samples using a USB digital microscope camera, a Raspberry Pi 4B and a YOLOv5s object-detection model.

> **Repository status:** This is a documentation and starter-code package. Add the actual source code, trained model weights, project report and original result images from your project before presenting this repository as the complete implementation. The example scripts are templates and must be tested with your hardware and trained model.

## Project overview

Microplastics are small plastic particles that can occur in water. This project aims to capture magnified images of water samples and use a trained YOLOv5 model to identify and count particles that resemble the classes represented in the training dataset.

## Objectives

- Capture images of water samples using a USB digital microscope camera.
- Use a trained YOLOv5s model to detect target particles in images.
- Explore running the detection workflow on a Raspberry Pi 4B.
- Display or save annotated detection results to support water-quality monitoring research.

## Hardware

- Raspberry Pi 4B
- USB digital microscope camera
- MicroSD card and suitable power supply
- Monitor, keyboard and mouse for setup (optional during deployment)

## Software and tools

- Raspberry Pi OS / Linux
- Python 3
- OpenCV (camera capture and image handling)
- PyTorch and the YOLOv5 repository (model inference)

Check the versions supported by the Raspberry Pi OS image and the YOLOv5 version used in your original project. PyTorch installation on Raspberry Pi can depend on the OS, Python version and processor architecture.

## System workflow

1. Prepare a water sample for microscope imaging.
2. Capture an image using the USB digital microscope camera.
3. Pass the image to the trained YOLOv5s model.
4. Display the predicted bounding boxes and class labels.
5. Review and record the detections for the sample.

## Dataset and model

The project report refers to a 577-image Kaggle dataset. Add the exact dataset title and source URL here so that others can identify the dataset. Do not upload a dataset unless its licence permits redistribution.

The project report identifies YOLOv5s as the detection model. The trained weights file (commonly named `best.pt`) is not included in this starter package. Place your own trained weights at `weights/best.pt` for the example inference script, subject to the model's size and applicable GitHub file limits. Do not claim that the sample script is your original training pipeline unless it matches your actual implementation.

## Reported results

The project report states **78.0% precision** and **70.1% mAP@50**. These are the reported project values, not a guarantee that every run or deployment will reproduce them. Add the evaluation split, class details and experiment settings from your report before making a formal comparison.

## Repository structure

```text
.
├── README.md
├── requirements.txt
├── .gitignore
├── src/
│   ├── capture.py
│   └── detect.py
├── docs/
│   └── REPORT_AND_REFERENCES.md
├── images/
│   └── README.md
├── weights/
│   └── README.md
├── data/
│   └── samples/
└── results/
```

## Setup

1. Install Python 3 on your Raspberry Pi or development computer.
2. Create and activate a virtual environment if compatible with your PyTorch installation.
3. Install the packages listed in `requirements.txt`.
4. Install/clone the YOLOv5 version used by your project and make sure its dependencies are available.
5. Put your trained model at `weights/best.pt`.
6. Connect the USB microscope camera.

Example commands:

```bash
python -m pip install -r requirements.txt
python src/capture.py --camera 0 --output data/samples
python src/detect.py --source 0 --weights weights/best.pt --view
```

The commands above are starter examples. The inference script loads YOLOv5 through PyTorch Hub and may need adjustment to match the exact YOLOv5 commit, checkpoint and Raspberry Pi software environment used in your project. For a headless Raspberry Pi, omit `--view` and use `--save-video results/detections.mp4` if video output is supported by your OpenCV build.

## Team and institution

- **Pranjali Gude**
- **Shruti Gaikwad**
- **Vaishanvi Lomate**
- **Project guide:** Prof. Utkarsha Gaikwad
- **Institution:** MIT College of Railway Engineering and Research (MITCORER), Barshi, Maharashtra, India

Please verify the author order, guide designation and institutional wording against your approved project report before submission.

## Limitations and future scope

The report identifies the need for a larger and more diverse dataset, improved image conditions, additional real-world water-sample testing, better detection accuracy and processing time, and further work toward polymer identification. Detection of a particle by this image-based model should not be treated as definitive chemical identification of plastic.

## Responsible use and citation

- Cite the dataset, YOLOv5 repository and any external code used.
- Respect dataset and model licences.
- Remove personal information from sample images and documents before publishing.
- Do not upload passwords, API keys or private credentials.

## Project report

Add your approved PDF report to `docs/` and update the filename/link here. The report is not included in this starter package because it was not attached to this message.
