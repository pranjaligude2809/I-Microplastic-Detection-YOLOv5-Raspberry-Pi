# Project images

Add your own project photographs here, for example:

- Raspberry Pi 4B setup
- USB digital microscope camera
- Water-sample imaging setup
- Example detection output

Use clear filenames such as `raspberry-pi-setup.jpg` and `yolov5-detection-result.jpg`. Make sure you have permission to publish the photographs and remove private information.
