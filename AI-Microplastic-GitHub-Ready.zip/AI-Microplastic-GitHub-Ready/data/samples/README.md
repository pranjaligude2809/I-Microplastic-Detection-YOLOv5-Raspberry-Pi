# Sample images

This folder is for images captured from your own USB microscope. Remove personal or sensitive information before sharing. Avoid committing the complete training dataset unless its licence explicitly permits redistribution.
