"""YOLOv5s inference on a USB microscope camera with optional I2C LCD logging.

This is an integration example adapted from the supplied project report's Appendix A.
It requires the team's own trained weights and a local YOLOv5 repository.
Run from the repository root, for example:
  python src/realtime_detector.py --yolov5-repo ../yolov5 --weights weights/best.pt
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime
from pathlib import Path
import sys
import time

import cv2


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Microplastic detection using local YOLOv5")
    p.add_argument("--yolov5-repo", type=Path, required=True, help="Path to cloned YOLOv5 repository")
    p.add_argument("--weights", type=Path, default=Path("weights/best.pt"), help="Trained YOLOv5 checkpoint")
    p.add_argument("--camera", type=int, default=0, help="OpenCV camera index; USB microscope is usually 0")
    p.add_argument("--img-size", type=int, default=640)
    p.add_argument("--conf", type=float, default=0.25)
    p.add_argument("--iou", type=float, default=0.45)
    p.add_argument("--csv", type=Path, default=Path("results/detections.csv"))
    p.add_argument("--lcd", action="store_true", help="Enable 16x2 PCF8574 I2C LCD at address 0x27")
    p.add_argument("--no-display", action="store_true", help="Do not open an OpenCV preview window")
    p.add_argument("--save-images", action="store_true", help="Save annotated camera frames in results/frames")
    return p.parse_args()


def preprocess(frame):
    """Apply Gaussian denoising and CLAHE contrast normalization, then return RGB."""
    frame = cv2.GaussianBlur(frame, (3, 3), 0)
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    lab[:, :, 0] = clahe.apply(lab[:, :, 0])
    normalized_bgr = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    return cv2.cvtColor(normalized_bgr, cv2.COLOR_BGR2RGB)


def lcd_init(enabled: bool):
    if not enabled:
        return None
    try:
        from RPLCD.i2c import CharLCD
        return CharLCD("PCF8574", 0x27, cols=16, rows=2)
    except Exception as exc:
        raise RuntimeError("Could not initialize I2C LCD. Check I2C is enabled, wiring and address 0x27.") from exc


def lcd_show(lcd, line1: str, line2: str = "") -> None:
    if lcd is None:
        return
    lcd.clear()
    lcd.write_string(line1[:16])
    lcd.cursor_pos = (1, 0)
    lcd.write_string(line2[:16])


def main() -> int:
    args = parse_args()
    if not 0 < args.conf < 1 or not 0 < args.iou < 1:
        print("--conf and --iou must be between 0 and 1.", file=sys.stderr)
        return 2
    if not args.yolov5_repo.is_dir():
        print(f"YOLOv5 repository not found: {args.yolov5_repo}", file=sys.stderr)
        return 2
    if not args.weights.is_file():
        print(f"Trained weights not found: {args.weights}. Add your own best.pt first.", file=sys.stderr)
        return 2

    try:
        import torch
        model = torch.hub.load(str(args.yolov5_repo.resolve()), "custom", path=str(args.weights.resolve()), source="local")
        model.conf = args.conf
        model.iou = args.iou
        lcd = lcd_init(args.lcd)
    except Exception as exc:
        print(f"Could not load model or initialize optional hardware: {exc}", file=sys.stderr)
        return 1

    cap = cv2.VideoCapture(args.camera)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    if not cap.isOpened():
        print(f"Could not open camera index {args.camera}. Check the microscope connection.", file=sys.stderr)
        return 1

    args.csv.parent.mkdir(parents=True, exist_ok=True)
    frame_dir = Path("results/frames")
    if args.save_images:
        frame_dir.mkdir(parents=True, exist_ok=True)

    csv_exists = args.csv.exists()
    try:
        with args.csv.open("a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if not csv_exists:
                writer.writerow(["timestamp", "frame", "particle_count", "inference_seconds"])
            lcd_show(lcd, "PolyScan Ready", "Camera starting")
            frame_no = 0
            while True:
                ok, frame = cap.read()
                if not ok:
                    lcd_show(lcd, "Camera Error", "Check USB cam")
                    print("Unable to read a camera frame.", file=sys.stderr)
                    time.sleep(0.5)
                    continue

                start = time.perf_counter()
                result = model(preprocess(frame), size=args.img_size)
                elapsed = time.perf_counter() - start
                detections = result.xyxy[0]
                count = int(len(detections))
                annotated = result.render()[0]
                frame_no += 1

                lcd_show(lcd, "MP Detected" if count else "Not Detected", f"Count: {count}")
                writer.writerow([datetime.now().isoformat(timespec="seconds"), frame_no, count, round(elapsed, 4)])
                f.flush()

                if args.save_images:
                    cv2.imwrite(str(frame_dir / f"frame_{frame_no:06d}.jpg"), annotated)
                if not args.no_display:
                    cv2.imshow("Microplastic Detection - press q to quit", annotated)
                    if (cv2.waitKey(1) & 0xFF) in (ord("q"), ord("Q")):
                        break
    except KeyboardInterrupt:
        print("Stopped by user.")
    except Exception as exc:
        print(f"Detection failed: {exc}", file=sys.stderr)
        return 1
    finally:
        cap.release()
        if not args.no_display:
            cv2.destroyAllWindows()
        if lcd is not None:
            try:
                lcd.clear()
            except Exception:
                pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
