# Reported model metrics

Values transcribed from the supplied project report; these are not independently re-evaluated in this repository.

| Metric | Value |
|---|---:|
| Precision | 0.780 |
| Recall | 0.618 |
| mAP@50 | 0.701 (peak 0.722 at epoch 45, as separately noted in the report) |
| mAP@50–95 | 0.330 |
| Best F1-score | 0.70 at confidence ≈ 0.241 |

Dataset: 577 annotated images (461 train, 116 validation), one class, 640 × 640 input, 50 epochs.

**Not reported as measured:** Raspberry Pi inference time/FPS and some live hardware test-case outputs. Record those from actual hardware tests before publishing performance claims.
