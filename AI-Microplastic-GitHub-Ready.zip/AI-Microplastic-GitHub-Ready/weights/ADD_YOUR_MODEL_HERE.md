# Model weights

Place the trained YOLOv5 checkpoint here as `best.pt` on your local machine. The actual model file was not supplied with the report and is not included in this package. `.pt` files are excluded by `.gitignore` by default. Share weights publicly only if you have the right to redistribute them and consider Git LFS for large files.
