# Public GitHub upload checklist

- [ ] Add the team's actual Python source files if they differ from the example in `src/`.
- [ ] Add the trained checkpoint `best.pt` to your local `weights/` folder only if you intend to share it; note that `.pt` is git-ignored by default and large files may require Git LFS or a release asset.
- [ ] Add the dataset source URL and verify its redistribution licence in `training/DATASET.md`.
- [ ] Add original prototype photographs and genuine detection-result screenshots.
- [ ] Measure Raspberry Pi inference time/FPS and fill missing hardware test results only after running the tests.
- [ ] Do not upload the unredacted project report: it includes PRN identifiers. Make a public-safe copy first if you want to share the report.
- [ ] Check all figure licences / attribution before public upload.
- [ ] Open the repository in a private/incognito browser window to confirm the public files and README display correctly.
