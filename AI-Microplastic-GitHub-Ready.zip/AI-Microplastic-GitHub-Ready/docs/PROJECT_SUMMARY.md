# Project Summary

## Title
AI-Based Real-Time Microplastics Detection System Using YOLOv5 and Raspberry Pi for Water Quality Monitoring

## Institution and team
- Department: Electronics and Telecommunication Engineering
- Institution: MAEER's MIT College of Railway Engineering and Research (MITCORER), Barshi
- Academic year: 2026–2027
- Students: Pranjali Gude, Shruti Gaikwad, Vaishnavi Lomate
- Project guide: Prof. Utkarsha Gaikwad

## Aim
Develop a portable, low-cost visual screening prototype that captures microscope images of water samples and detects/counts microplastic-like particles using a YOLOv5s object detector on a Raspberry Pi 4B.

## Main components
- Raspberry Pi 4B (4 GB RAM)
- TOBO USB digital microscope (reported magnification range 50×–1600×)
- 16×2 I²C LCD (PCF8574 interface)
- 32 GB Class 10 microSD card
- 5 V / 3 A USB-C power supply

## Software
Raspberry Pi OS 64-bit, Python 3, PyTorch, YOLOv5s, OpenCV, NumPy, RPLCD/smbus2, Google Colab GPU and Makesense.ai annotation.

## Dataset and model
The report states that the model was fine-tuned from COCO-pretrained YOLOv5s weights using 577 annotated images from the Kaggle Microplastic Dataset for Computer Vision: 461 training images and 116 validation images. Input size was 640 × 640 pixels and training ran for 50 epochs. The detector has one class: `Microplastic`.

## Reported validation results
- Precision: 0.780
- Recall: 0.618
- mAP@50: 0.701 (the report notes a peak value of 0.722 at epoch 45)
- mAP@50–95: 0.330
- Best F1-score: 0.70 at confidence threshold approximately 0.241

## Workflow
Microscope capture → OpenCV Gaussian denoising and CLAHE contrast normalization → YOLOv5s inference → non-maximum suppression → particle count/status → LCD display and local CSV logging.

## Limitations
This is visual screening, not chemical polymer identification. The report also states that measured Raspberry Pi inference time and several end-to-end test outputs were still to be recorded; these should be measured before making real-time speed claims.
