# AI-Based Real-Time Microplastics Detection System Using YOLOv5 and Raspberry Pi

A capstone project from the Electronics and Telecommunication Engineering Department, MITCORER, Barshi. The project investigates image-based detection and counting of microplastic-like particles in water samples using a USB digital microscope, OpenCV, a YOLOv5s detector and a Raspberry Pi 4B.

> **Repository status:** This GitHub package contains project documentation, report-derived figures and an example Raspberry Pi inference script based on the software appendix in the project report. It does **not** contain the team's trained `best.pt` weights or the original Kaggle dataset. The Python script must be checked against the team's actual hardware, local YOLOv5 checkout and model weights before it is described as a tested release.

## Project overview

The proposed workflow captures magnified frames from a USB digital microscope, performs image pre-processing with OpenCV, runs the custom YOLOv5s model, counts detections and displays the detection status/count on a 16×2 I²C LCD. The report also describes saving detection information locally to a CSV file on the Raspberry Pi microSD card. The intended deployment is offline after the model and dependencies have been installed.

## System workflow

1. Prepare a water sample on a clean Petri dish or glass slide and focus the microscope.
2. Capture a frame using the USB microscope connected to the Raspberry Pi 4B.
3. Apply Gaussian denoising and CLAHE contrast normalization using OpenCV.
4. Resize/letterbox the image for the YOLOv5s model (640-pixel inference input).
5. Run detection and non-maximum suppression using the configured confidence and IoU thresholds.
6. Count the remaining detections, show the status/count on the 16×2 I²C LCD, and log the timestamp/count locally.

## Hardware reported in the project

| Component | Reported specification / role |
|---|---|
| Processing board | Raspberry Pi 4B, 4 GB RAM, 1.5 GHz quad-core Cortex-A72 |
| Microscope | TOBO USB digital microscope, 50×–1600×, UVC USB camera |
| Display | 16×2 I²C LCD with PCF8574 adapter |
| Storage | 32 GB Class 10 microSD card |
| Power | 5 V / 3 A USB-C supply |
| Sample handling | Petri dish / glass slide; manual sample preparation and focusing |

## Software and tools reported

- Raspberry Pi OS (64-bit)
- Python 3
- PyTorch
- Ultralytics YOLOv5 (YOLOv5s)
- OpenCV and NumPy
- RPLCD / smbus2 for the I²C LCD
- Google Colab GPU for model training
- Makesense.ai for YOLO-format annotation

## Dataset and training configuration

The report identifies the public Kaggle **Microplastic Dataset for Computer Vision**. The reported training setup is:

| Setting | Value |
|---|---:|
| Annotated images | 577 |
| Training images | 461 |
| Validation images | 116 |
| Classes | 1 (`Microplastic`) |
| Annotation | YOLO normalized bounding boxes |
| Input size | 640 × 640 |
| Model | YOLOv5s, initialized from COCO-pretrained `yolov5s.pt` |
| Training epochs | 50 |
| Optimizer | SGD (YOLOv5 defaults, as stated in report) |
| Confidence threshold | 0.25 |
| IoU/NMS threshold | 0.45 |

The dataset itself is not included in this repository. Add the dataset's verified URL and licence information to `training/DATASET.md` before publishing or redistributing any dataset files. Do not upload data unless its licence permits it.

## Reported model results

The project report gives the following validation results after 50 training epochs:

| Metric | Reported value |
|---|---:|
| Precision | 0.780 (78.0%) |
| Recall | 0.618 (61.8%) |
| mAP@50 | 0.701 (70.1%); report also notes a peak of 0.722 at epoch 45 |
| mAP@50–95 | 0.330 (33.0%) |
| Best F1-score | 0.70 at confidence threshold about 0.241 |

These are the values reported for the model validation experiment. The report's Raspberry Pi test table leaves some hardware checks and the measured inference time per frame as **to be recorded**. Therefore, this repository does not claim a measured Raspberry Pi FPS or end-to-end latency. Add those measurements only after testing the actual device.

## Example figures from the project report

### Proposed hardware system layout

![Proposed system layout](images/system-layout.png)

### Raspberry Pi 4B board reference

![Raspberry Pi 4B board](images/raspberry-pi-4b.png)

### USB digital microscope reference

![USB digital microscope](images/usb-microscope.jpg)

### Example YOLOv5 detection outputs shown in the report

![Example detection outputs](images/detection-examples.jpg)

> Figures are extracted from the supplied project report. Verify any third-party image reuse rights and add original prototype photographs where available.

## Repository contents

```text
.
├── README.md
├── requirements.txt
├── .gitignore
├── src/
│   ├── capture.py
│   └── realtime_detector.py
├── training/
│   ├── DATASET.md
│   └── data.yaml
├── docs/
│   ├── PROJECT_SUMMARY.md
│   └── PUBLIC_UPLOAD_CHECKLIST.md
├── images/
├── results/
│   └── REPORTED_METRICS.md
├── data/samples/        # local sample images; do not commit private/raw data
└── weights/             # add your own best.pt locally; ignored by Git
```

## Setup notes

1. Install Raspberry Pi OS 64-bit and Python 3 on the Raspberry Pi.
2. Clone the YOLOv5 version used by the project and install its dependencies according to that version's instructions.
3. Install OpenCV and RPLCD in a Python environment compatible with your PyTorch and YOLOv5 versions.
4. Copy your trained checkpoint to `weights/best.pt` (the weights are not included here).
5. Connect the USB microscope and I²C LCD. Confirm the LCD I²C address; the report's code example uses `0x27`.
6. Test camera capture first. Then run the inference script and compare LCD counts with manually reviewed images.

Example camera capture:

```bash
python -m pip install -r requirements.txt
python src/capture.py --camera 0 --output data/samples
```

Example detector command (run from the repository root):

```bash
python src/realtime_detector.py \
  --yolov5-repo ../yolov5 \
  --weights weights/best.pt \
  --camera 0
```

The PyTorch installation on Raspberry Pi depends on Raspberry Pi OS, Python and CPU architecture. Install a compatible PyTorch build separately if the default `pip install torch` does not work. The detector script is an integration example, not a guarantee of plug-and-play compatibility.

## Team and institution

- **Pranjali Gude**
- **Shruti Gaikwad**
- **Vaishnavi Lomate**
- **Project guide:** Prof. Utkarsha Gaikwad
- **Department:** Electronics and Telecommunication Engineering
- **Institution:** MAEER's MIT College of Railway Engineering and Research (MITCORER), Barshi, Maharashtra, India
- **Academic year:** 2026–2027

## Limitations and future scope

- The detector is visual and does not chemically identify polymer types such as PE, PP, PS or PET.
- The reported dataset contains 577 images; performance may decrease under different lighting, magnification, sample backgrounds or water conditions.
- Particles below the optical resolution of the microscope and nanoplastics cannot be detected reliably by this setup.
- Sample preparation and microscope focusing are manual.
- The report notes that Raspberry Pi inference-time/FPS measurements and several end-to-end hardware test observations still need to be recorded.
- Future work includes adding more locally captured and annotated water-sample images, improving recall and processing speed, and comparing screening results with laboratory FTIR/Raman analysis.

## Public repository and privacy note

The supplied full report contains student PRN identifiers. **Do not upload the unredacted report to a public repository.** Create a public-safe PDF copy with PRNs, phone/email details, signatures and any other private identifiers removed, or keep the full report private and upload this concise project summary instead.

Do not upload passwords, API keys, private credentials, or files you do not have permission to redistribute.
