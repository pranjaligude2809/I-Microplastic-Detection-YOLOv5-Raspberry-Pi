# Dataset details

The report identifies the Kaggle dataset as **Microplastic Dataset for Computer Vision**, with 577 annotated images (461 training / 116 validation), one class (`Microplastic`), YOLO-format bounding boxes and 640 × 640 model input.

Before sharing a dataset link or data files, add the exact verified Kaggle URL and review the dataset licence. The dataset is not included in this repository.
